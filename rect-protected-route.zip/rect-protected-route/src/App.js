import './App.css';
import Allroutes from './routes/Allroutes';


function App() {
  return (
    <div className="App">
 <Allroutes/>
     
    </div>
  );
}

export default App;
