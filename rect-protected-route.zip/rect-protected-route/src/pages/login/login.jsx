import React from 'react'

export default function Login(props) {
  return (
    <div>
      <input type="text" placeholder="userName"/><br/>
      <input type="text" placeholder="userName"/><br/>
      <input type="submit" value="submit" onClick={()=>{props.setAuth(true)}}/>
    </div>
  )
}
