import React from 'react'

export default function Signup() {
    return (
        <div>
          <div>
      <input type="text" placeholder="userName"/><br/>
      <input type="text" placeholder="userName"/><br/>
      <input type="submit" value="Register"/>
    </div>
        </div>
    )
}
