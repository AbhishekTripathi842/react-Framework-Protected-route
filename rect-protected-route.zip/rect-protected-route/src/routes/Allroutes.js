import React, { Fragment, useState } from 'react'
import Login from '../pages/login/login'
import Dashboard from '../pages/dashboard/Dashboard';
import Signup from '../pages/signup/signup';
import { BrowserRouter, Routes, Navigate, Outlet, Route } from "react-router-dom";
import Navbar from '../components/navbar/navbar';

import {
  LOGIN, DASHBOARD, SIGNUP
} from './Routepath';

let Allroutes = () => {

  const [auth, setAuth] = useState(false)

  const PrivateRoute = () => {
    // If authorized, return an outlet that will render child elements
    // If not, return element that will navigate to login page
    return auth ? <Outlet /> : <Navigate to={LOGIN} />;
  }


  const LoginRoute = () => {
    // If authorized, return an outlet that will render child elements
    // If not, return element that will navigate to login page
    return !auth ? <Outlet /> : <Navigate to={DASHBOARD} />;
  }

  


  return (
    <BrowserRouter>
      <Fragment>
      <Navbar auth={auth}/>
        <Routes>
          <Route exact path={DASHBOARD} element={<PrivateRoute />}>
            <Route exact path={DASHBOARD} element={<Dashboard />} />
          </Route>

          <Route exact path={LOGIN} element={<LoginRoute />}>
            <Route exact path={LOGIN} element={<Login setAuth={setAuth} />} />
          </Route>

          {/* <Route path={LOGIN} element={<Login />} /> */}
          <Route exact path={SIGNUP} element={<LoginRoute />}>
          <Route exact path={SIGNUP} element={<Signup />} />
          </Route>
        </Routes>
      </Fragment>
    </BrowserRouter>
  )
}

export default Allroutes