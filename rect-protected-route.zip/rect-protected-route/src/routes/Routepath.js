export const LOGIN = "/auth/login";
export const DASHBOARD = "/Dashboard";
export const SIGNUP = "/auth/Signup"
